import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getToken } from "@/lib/auth";
import { MapPin, Clock, Utensils, TrendingUp, Package } from "lucide-react";
import type { User, Order } from "@shared/schema";

export default function Dashboard() {
  const [, setLocation] = useLocation();

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
    enabled: !!getToken(),
  });

  const { data: orders } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: !!getToken(),
  });

  if (!getToken()) {
    setLocation("/login");
    return null;
  }

  const activeOrder = orders?.find(o => o.status !== "DELIVERED");
  const completedToday = orders?.filter(o => {
    if (!o.completedAt) return false;
    const today = new Date().toDateString();
    return new Date(o.completedAt).toDateString() === today;
  });

  return (
    <div className="p-4 max-w-lg mx-auto space-y-6">
      {/* Welcome Card */}
      <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
        <CardHeader>
          <CardTitle className="text-2xl">Welcome back, {user?.name}!</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-primary" />
                <span className="text-lg font-semibold">${user?.totalEarnings}</span>
              </div>
              <p className="text-sm text-muted-foreground">Total Earnings</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Package className="w-4 h-4 text-primary" />
                <span className="text-lg font-semibold">{completedToday?.length || 0}</span>
              </div>
              <p className="text-sm text-muted-foreground">Today's Deliveries</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Order */}
      {activeOrder ? (
        <Card className="relative overflow-hidden">
          <div className="absolute top-0 right-0 p-2">
            <Badge variant={activeOrder.status === "PICKED_UP" ? "default" : "secondary"}>
              {activeOrder.status}
            </Badge>
          </div>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Utensils className="w-5 h-5 text-primary" />
              Active Order #{activeOrder.id}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-1 text-muted-foreground" />
                  <div>
                    <p className="font-medium">Pickup</p>
                    <p className="text-sm text-muted-foreground">{activeOrder.pickupAddress}</p>
                  </div>
                </div>
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 mt-1 text-primary" />
                  <div>
                    <p className="font-medium">Delivery</p>
                    <p className="text-sm text-muted-foreground">{activeOrder.deliveryAddress}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">
                    Assigned {new Date(activeOrder.assignedAt).toLocaleTimeString()}
                  </span>
                </div>
                <Button onClick={() => setLocation(`/orders`)}>
                  View Details
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="py-8">
            <div className="text-center space-y-2">
              <Package className="w-12 h-12 text-muted-foreground mx-auto" />
              <p className="text-lg font-medium">No Active Orders</p>
              <p className="text-sm text-muted-foreground">
                New orders will appear here when assigned
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}