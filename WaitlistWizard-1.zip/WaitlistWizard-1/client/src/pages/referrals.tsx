import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

export default function Referrals() {
  const { toast } = useToast();

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user"],
  });

  async function copyReferralCode() {
    if (user?.referralCode) {
      try {
        await navigator.clipboard.writeText(user.referralCode);
        toast({
          title: "Copied!",
          description: "Referral code copied to clipboard",
        });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to copy referral code",
        });
      }
    }
  }

  return (
    <div className="p-4 max-w-md mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Your Referral Code</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-muted p-4 rounded-lg text-center">
            <p className="text-2xl font-mono font-bold">{user?.referralCode}</p>
          </div>
          <Button 
            className="w-full" 
            onClick={copyReferralCode}
          >
            Copy Code
          </Button>
          <p className="text-sm text-muted-foreground text-center">
            Share this code with other delivery partners and earn rewards when they join!
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="list-decimal list-inside space-y-2 text-muted-foreground">
            <li>Share your referral code with potential delivery partners</li>
            <li>They enter your code when signing up</li>
            <li>Once they complete their first delivery, you earn a bonus!</li>
          </ol>
        </CardContent>
      </Card>

      {user?.referredBy && (
        <Card>
          <CardHeader>
            <CardTitle>Your Referrer</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center text-muted-foreground">
              You were referred by partner #{user.referredBy}
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
