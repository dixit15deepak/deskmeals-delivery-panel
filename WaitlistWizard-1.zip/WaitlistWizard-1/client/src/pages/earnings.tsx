import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { format } from "date-fns";
import type { Order } from "@shared/schema";

export default function Earnings() {
  const { data: orders } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  const completedOrders = orders?.filter(o => o.status === "DELIVERED") || [];
  const totalEarnings = completedOrders.reduce((sum, order) => sum + order.earnings, 0);

  // Group orders by date
  const ordersByDate = completedOrders.reduce((acc, order) => {
    const date = format(new Date(order.completedAt!), "MMM d, yyyy");
    if (!acc[date]) acc[date] = [];
    acc[date].push(order);
    return acc;
  }, {} as Record<string, Order[]>);

  return (
    <div className="p-4 max-w-md mx-auto space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Total Earnings</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-4xl font-bold">${totalEarnings}</p>
        </CardContent>
      </Card>

      {Object.entries(ordersByDate).map(([date, orders]) => (
        <div key={date} className="space-y-4">
          <h2 className="text-xl font-bold">{date}</h2>
          {orders.map(order => (
            <Card key={order.id}>
              <CardContent className="pt-6">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">Order #{order.id}</p>
                    <p className="text-sm text-muted-foreground">
                      {format(new Date(order.completedAt!), "h:mm a")}
                    </p>
                  </div>
                  <p className="text-xl font-bold">${order.earnings}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ))}
    </div>
  );
}
