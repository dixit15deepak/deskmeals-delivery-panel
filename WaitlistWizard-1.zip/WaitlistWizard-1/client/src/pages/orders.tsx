import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { MapPin, Phone, Clock, Check, ChevronRight, Package, Utensils } from "lucide-react";
import type { Order } from "@shared/schema";

function OrderCard({ order }: { order: Order }) {
  const updateStatus = useMutation({
    mutationFn: async (status: string) => {
      await apiRequest("PATCH", `/api/orders/${order.id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
    },
  });

  const statusColors = {
    ASSIGNED: "secondary",
    PICKED_UP: "default",
    DELIVERED: "success",
  } as const;

  const statusIcon = {
    ASSIGNED: Package,
    PICKED_UP: Utensils,
    DELIVERED: Check,
  }[order.status];

  const StatusIcon = statusIcon;

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 right-0 p-3">
        <Badge variant={statusColors[order.status as keyof typeof statusColors]}>
          <div className="flex items-center gap-1">
            {StatusIcon && <StatusIcon className="w-3 h-3" />}
            {order.status}
          </div>
        </Badge>
      </div>

      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Order #{order.id}</span>
          <span className="text-base font-normal text-muted-foreground">
            ${order.earnings}
          </span>
        </CardTitle>
      </CardHeader>

      <CardContent>
        <div className="space-y-4">
          <div className="space-y-2">
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 mt-1 text-muted-foreground" />
              <div>
                <p className="font-medium">Pickup</p>
                <p className="text-sm text-muted-foreground">{order.pickupAddress}</p>
              </div>
            </div>
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 mt-1 text-primary" />
              <div>
                <p className="font-medium">Delivery</p>
                <p className="text-sm text-muted-foreground">{order.deliveryAddress}</p>
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">
                  {new Date(order.assignedAt).toLocaleTimeString()}
                </span>
              </div>
              <Button variant="ghost" size="sm" className="h-8" asChild>
                <a href={`tel:${order.customerPhone}`} className="flex items-center gap-1">
                  <Phone className="w-4 h-4" />
                  Call Customer
                </a>
              </Button>
            </div>

            {order.status === "ASSIGNED" && (
              <Button
                className="w-full"
                onClick={() => updateStatus.mutate("PICKED_UP")}
              >
                Mark as Picked Up
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            )}

            {order.status === "PICKED_UP" && (
              <Button
                className="w-full"
                onClick={() => updateStatus.mutate("DELIVERED")}
              >
                Mark as Delivered
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Orders() {
  const { data: orders, isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
  });

  if (isLoading) {
    return (
      <div className="p-4 max-w-lg mx-auto">
        <Card>
          <CardContent className="py-8">
            <div className="text-center space-y-2">
              <Package className="w-12 h-12 text-muted-foreground/50 mx-auto animate-pulse" />
              <p className="text-lg font-medium">Loading orders...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const activeOrders = orders?.filter(o => o.status !== "DELIVERED") || [];
  const completedOrders = orders?.filter(o => o.status === "DELIVERED") || [];

  return (
    <div className="p-4 max-w-lg mx-auto space-y-6">
      <div className="space-y-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Package className="w-5 h-5" />
          Active Orders
        </h2>
        {activeOrders.map(order => (
          <OrderCard key={order.id} order={order} />
        ))}
        {activeOrders.length === 0 && (
          <Card>
            <CardContent className="py-8">
              <div className="text-center space-y-2">
                <Package className="w-12 h-12 text-muted-foreground mx-auto" />
                <p className="text-lg font-medium">No Active Orders</p>
                <p className="text-sm text-muted-foreground">
                  New orders will appear here when assigned
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <div className="space-y-4">
        <h2 className="text-xl font-bold flex items-center gap-2">
          <Check className="w-5 h-5" />
          Completed Orders
        </h2>
        {completedOrders.map(order => (
          <OrderCard key={order.id} order={order} />
        ))}
        {completedOrders.length === 0 && (
          <p className="text-center text-muted-foreground py-4">
            No completed orders yet
          </p>
        )}
      </div>
    </div>
  );
}