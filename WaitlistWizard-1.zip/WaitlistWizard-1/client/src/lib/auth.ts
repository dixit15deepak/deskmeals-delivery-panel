import { apiRequest } from "./queryClient";

export async function login(phone: string) {
  return apiRequest("POST", "/api/auth/login", { phone });
}

export async function verifyOtp(phone: string, code: string) {
  return apiRequest("POST", "/api/auth/verify", { phone, code });
}

export function setToken(token: string) {
  localStorage.setItem("token", token);
}

export function getToken() {
  return localStorage.getItem("token");
}

export function clearToken() {
  localStorage.removeItem("token");
}
