import { Link, useLocation } from "wouter";
import { Home, Package, User, DollarSign, Users } from "lucide-react";

export function NavMenu() {
  const [location] = useLocation();

  const items = [
    { href: "/", icon: Home, label: "Dashboard" },
    { href: "/orders", icon: Package, label: "Orders" },
    { href: "/earnings", icon: DollarSign, label: "Earnings" },
    { href: "/referrals", icon: Users, label: "Referrals" },
    { href: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
      <div className="flex justify-between max-w-md mx-auto">
        {items.map((item) => (
          <Link key={item.href} href={item.href}>
            <a className={`flex flex-col items-center p-2 ${
              location === item.href ? "text-primary" : "text-gray-500"
            }`}>
              <item.icon className="w-6 h-6" />
              <span className="text-xs mt-1">{item.label}</span>
            </a>
          </Link>
        ))}
      </div>
    </nav>
  );
}
