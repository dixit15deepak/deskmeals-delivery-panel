import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull().unique(),
  name: text("name").notNull(),
  isVerified: boolean("is_verified").default(false),
  rating: integer("rating").default(0),
  totalEarnings: integer("total_earnings").default(0),
  activeOrderId: integer("active_order_id"),
  referralCode: text("referral_code").notNull().unique(),
  referredBy: integer("referred_by"),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  deliveryPartnerId: integer("delivery_partner_id").notNull(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  pickupAddress: text("pickup_address").notNull(),
  deliveryAddress: text("delivery_address").notNull(),
  status: text("status").notNull(), // ASSIGNED, PICKED_UP, DELIVERED
  amount: integer("amount").notNull(),
  earnings: integer("earnings").notNull(),
  assignedAt: timestamp("assigned_at").notNull(),
  completedAt: timestamp("completed_at"),
});

export const otps = pgTable("otps", {
  id: serial("id").primaryKey(),
  phone: text("phone").notNull(),
  code: text("code").notNull(),
  expiresAt: timestamp("expires_at").notNull(),
  verified: boolean("verified").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  phone: true,
  name: true,
  referralCode: true,
  referredBy: true,
});

export const insertOrderSchema = createInsertSchema(orders).pick({
  customerName: true,
  customerPhone: true,
  pickupAddress: true,
  deliveryAddress: true,
  amount: true,
  earnings: true,
});

export const loginSchema = z.object({
  phone: z.string().min(10).max(15),
});

export const verifyOtpSchema = z.object({
  phone: z.string().min(10).max(15),
  code: z.string().length(6),
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Order = typeof orders.$inferSelect;
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type OTP = typeof otps.$inferSelect;
