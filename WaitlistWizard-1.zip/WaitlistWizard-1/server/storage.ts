import { users, orders, otps, type User, type InsertUser, type Order, type InsertOrder, type OTP } from "@shared/schema";
import { nanoid } from "nanoid";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, update: Partial<User>): Promise<User>;
  
  // Order operations
  getOrder(id: number): Promise<Order | undefined>;
  getOrdersByUser(userId: number): Promise<Order[]>;
  createOrder(order: InsertOrder & { deliveryPartnerId: number }): Promise<Order>;
  updateOrderStatus(id: number, status: string): Promise<Order>;
  
  // OTP operations
  createOtp(phone: string): Promise<OTP>;
  verifyOtp(phone: string, code: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private orders: Map<number, Order>;
  private otps: Map<number, OTP>;
  private currentIds: { users: number; orders: number; otps: number };

  constructor() {
    this.users = new Map();
    this.orders = new Map();
    this.otps = new Map();
    this.currentIds = { users: 1, orders: 1, otps: 1 };
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.phone === phone);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentIds.users++;
    const user: User = {
      ...insertUser,
      id,
      isVerified: false,
      rating: 0,
      totalEarnings: 0,
      activeOrderId: null,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, update: Partial<User>): Promise<User> {
    const user = await this.getUser(id);
    if (!user) throw new Error("User not found");
    
    const updatedUser = { ...user, ...update };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async getOrdersByUser(userId: number): Promise<Order[]> {
    return Array.from(this.orders.values())
      .filter(order => order.deliveryPartnerId === userId);
  }

  async createOrder(order: InsertOrder & { deliveryPartnerId: number }): Promise<Order> {
    const id = this.currentIds.orders++;
    const newOrder: Order = {
      ...order,
      id,
      status: "ASSIGNED",
      assignedAt: new Date(),
      completedAt: null,
    };
    this.orders.set(id, newOrder);
    return newOrder;
  }

  async updateOrderStatus(id: number, status: string): Promise<Order> {
    const order = await this.getOrder(id);
    if (!order) throw new Error("Order not found");
    
    const updatedOrder = {
      ...order,
      status,
      completedAt: status === "DELIVERED" ? new Date() : order.completedAt,
    };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async createOtp(phone: string): Promise<OTP> {
    const id = this.currentIds.otps++;
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const otp: OTP = {
      id,
      phone,
      code,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000), // 10 minutes
      verified: false,
    };
    this.otps.set(id, otp);
    return otp;
  }

  async verifyOtp(phone: string, code: string): Promise<boolean> {
    const otp = Array.from(this.otps.values())
      .find(otp => otp.phone === phone && !otp.verified);
    
    if (!otp) return false;
    if (otp.expiresAt < new Date()) return false;
    if (otp.code !== code) return false;
    
    const updatedOtp = { ...otp, verified: true };
    this.otps.set(otp.id, updatedOtp);
    return true;
  }
}

export const storage = new MemStorage();
