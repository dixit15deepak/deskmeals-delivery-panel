import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import jwt from "jsonwebtoken";
import { loginSchema, verifyOtpSchema, insertUserSchema } from "@shared/schema";

const JWT_SECRET = process.env.JWT_SECRET || "super-secret";

export async function registerRoutes(app: Express) {
  const httpServer = createServer(app);

  // Auth routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      const otp = await storage.createOtp(data.phone);
      // In production, send OTP via SMS
      res.json({ message: "OTP sent successfully", code: otp.code });
    } catch (error) {
      res.status(400).json({ message: "Invalid phone number" });
    }
  });

  app.post("/api/auth/verify", async (req, res) => {
    try {
      const data = verifyOtpSchema.parse(req.body);
      const isValid = await storage.verifyOtp(data.phone, data.code);
      
      if (!isValid) {
        return res.status(400).json({ message: "Invalid OTP" });
      }

      let user = await storage.getUserByPhone(data.phone);
      if (!user) {
        const referralCode = Math.random().toString(36).substring(2, 8).toUpperCase();
        user = await storage.createUser({
          phone: data.phone,
          name: "New Partner",
          referralCode,
          referredBy: null,
        });
      }

      const token = jwt.sign({ userId: user.id }, JWT_SECRET);
      res.json({ token, user });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  // Protected routes middleware
  const auth = async (req: any, res: any, next: any) => {
    try {
      const token = req.headers.authorization?.split(" ")[1];
      if (!token) throw new Error();
      
      const decoded = jwt.verify(token, JWT_SECRET) as { userId: number };
      req.user = await storage.getUser(decoded.userId);
      if (!req.user) throw new Error();
      
      next();
    } catch (error) {
      res.status(401).json({ message: "Unauthorized" });
    }
  };

  // User routes
  app.get("/api/user", auth, async (req: any, res) => {
    res.json(req.user);
  });

  app.patch("/api/user", auth, async (req: any, res) => {
    try {
      const user = await storage.updateUser(req.user.id, req.body);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid update" });
    }
  });

  // Order routes
  app.get("/api/orders", auth, async (req: any, res) => {
    const orders = await storage.getOrdersByUser(req.user.id);
    res.json(orders);
  });

  app.patch("/api/orders/:id/status", auth, async (req: any, res) => {
    try {
      const order = await storage.updateOrderStatus(parseInt(req.params.id), req.body.status);
      res.json(order);
    } catch (error) {
      res.status(400).json({ message: "Invalid status update" });
    }
  });

  return httpServer;
}
