# Desk Meals - Delivery Partner Panel

A full-stack delivery partner management system built with React, Express, and TypeScript.

## Features

🚀 **Authentication**
- OTP-based phone authentication
- Secure JWT session management

📦 **Order Management**
- Real-time order tracking
- Order status updates (Assigned → Picked Up → Delivered)
- Detailed delivery information

💰 **Earnings & Referrals**
- Daily/weekly earnings tracking
- Customer referral system
- Unique referral code generation

👤 **Profile Management**
- Partner profile customization
- Performance metrics tracking
- Earnings history

## Tech Stack

- Frontend: React + TypeScript
- Backend: Express.js
- State Management: TanStack Query
- UI Components: shadcn/ui
- Styling: Tailwind CSS
- Database: PostgreSQL (configurable)

## Getting Started

### Prerequisites
- Node.js 18+ and npm
- Git

### Installation

1. Clone the repository
```bash
git clone https://github.com/your-username/desk-meals-delivery.git
cd desk-meals-delivery
```

2. Install dependencies
```bash
npm install
```

3. Set up environment variables
Create a `.env` file in the root directory:
```env
JWT_SECRET=your-secret-key
DATABASE_URL=your-database-url # Optional, defaults to in-memory storage
```

4. Start the development server
```bash
npm run dev
```

The application will be available at `http://localhost:5000`

### Testing the Application

1. Access the login page
2. Enter a phone number (e.g., "1234567890")
3. For development, the OTP will be shown in the API response
4. Enter the OTP to log in
5. Explore features:
   - Dashboard: View active orders and earnings
   - Orders: Manage deliveries and update status
   - Earnings: Track your income
   - Profile: Update your information
   - Referrals: Share your referral code

## Production Deployment

1. Build the application
```bash
npm run build
```

2. Start the production server
```bash
npm start
```

## Development Guidelines

### Database Configuration
- By default, the application uses in-memory storage
- To use PostgreSQL, set the `DATABASE_URL` environment variable
- Database schema is managed through Drizzle ORM

### API Endpoints

#### Authentication
- POST `/api/auth/login`: Request OTP
- POST `/api/auth/verify`: Verify OTP and get JWT

#### User Operations
- GET `/api/user`: Get user profile
- PATCH `/api/user`: Update user profile

#### Orders
- GET `/api/orders`: List all orders
- PATCH `/api/orders/:id/status`: Update order status

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

MIT License - feel free to use this code for your own projects!